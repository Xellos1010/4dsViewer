﻿using UnityEngine;
using UnityEditor;
using System;

public class LoadNextPrefab : MonoBehaviour {
    
    int iPrefab = -1;
    internal void NextPrefab()
    {
        iPrefab = iPrefab + 1 < transform.childCount? iPrefab + 1 : 0;
        ActivateChild(iPrefab);
    }

    internal void ActivateChild(int v)
    {
        for (int i = 0; i < transform.childCount; i++)
        {
            if (i == v)
                transform.GetChild(i).gameObject.SetActive(true);
            else
                transform.GetChild(i).gameObject.SetActive(false);
        }
        iPrefab = v;
    }
}
[CustomEditor(typeof(LoadNextPrefab))]
public class LoadNextPrefabEditor:Editor
{
    LoadNextPrefab myTarget;


    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        myTarget = (LoadNextPrefab)target;
        if (GUILayout.Button("Activate First Child"))
        {
            myTarget.ActivateChild(0);
        }
        if (GUILayout.Button("Load Next Prefab"))
        {
            myTarget.NextPrefab();
        }
    }
}